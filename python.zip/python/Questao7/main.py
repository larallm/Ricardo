class Escola:
    def __init__(self):
        self.nome = ""
        self.professores = []

    def get_nome(self):
        return self.nome

    def set_nome(self, nome):
        self.nome = nome

    def get_professores(self):
        return self.professores

    def adicionar_professor(self, professor):
        self.professores.append(professor)


class Professor:
    def __init__(self):
        self.nome_professor = ""
        self.telefone = ""
        self.escolas = []

    def get_nome_professor(self):
        return self.nome_professor

    def set_nome_professor(self, nome_professor):
        self.nome_professor = nome_professor

    def get_telefone(self):
        return self.telefone

    def set_telefone(self, telefone):
        self.telefone = telefone

    def adicionar_escola(self, escola):
        self.escolas.append(escola)

    def get_escolas(self):
        return self.escolas


def contratar_professor(escola, nome_professor):
    if escola is None:
        print("Não é possível contratar um professor. Escola não cadastrada.")
        return

    novo_professor = Professor()
    novo_professor.set_nome_professor(nome_professor)

    escola.adicionar_professor(novo_professor)
    novo_professor.adicionar_escola(escola)
    print(f"Professor {nome_professor} contratado com sucesso!")


def cadastrar_escola(nome):
    escola = Escola()
    escola.set_nome(nome)
    return escola


def cadastrar_professor(nome_professor):
    professor = Professor()
    professor.set_nome_professor(nome_professor)
    return professor


def exibir_informacoes_professor(professor):
    if professor is None:
        print("Nenhum professor cadastrado.")
    else:
        print("Informações do Professor:")
        print(f"Nome do Professor: {professor.get_nome_professor()}")
        print(f"Telefone do Professor: {professor.get_telefone()}")
        print("Escolas associadas ao Professor:")

        escolas = professor.get_escolas()
        if not escolas:
            print("Nenhuma escola associada.")
        else:
            for escola in escolas:
                print(f" - {escola.get_nome()}")


def main():
    escola = None
    professor = None

    while True:
        print("\nMenu:")
        print("1. Contratar Professor")
        print("2. Cadastro Professor")
        print("3. Cadastro Escola")
        print("4. Informações Professor")
        print("5. Sair")
        opcao = input("Escolha uma opção: ")

        if opcao == '1':
            if escola:
                nome_professor = input("Digite o nome do professor a ser contratado: ")
                contratar_professor(escola, nome_professor)
            else:
                print("Não é possível contratar um professor. Escola não cadastrada.")

        elif opcao == '2':
            nome_professor = input("Digite o nome do professor: ")
            professor = cadastrar_professor(nome_professor)
            if escola:
                escola.adicionar_professor(professor)
                professor.adicionar_escola(escola)

        elif opcao == '3':
            nome_escola = input("Digite o nome da escola: ")
            escola = cadastrar_escola(nome_escola)

        elif opcao == '4':
            exibir_informacoes_professor(professor)

        elif opcao == '5':
            print("Encerrando o programa.")
            break

        else:
            print("Opção inválida.")


if __name__ == "__main__":
    main()
