class Animal:
    def __init__(self, nome):
        self.nome = nome

    def get_nome(self):
        return self.nome

    def som(self):
        print("O animal faz esse som")

class Gato(Animal):
    def __init__(self, nome):
        super().__init__(nome)

    def som(self):
        print("Miau!")

class Cachorro(Animal):
    def __init__(self, nome):
        super().__init__(nome)

    def som(self):
        print("Au")

if __name__ == "__main__":
    cachorro = Cachorro("Pituca")
    gato = Gato("Charlotte")

    print(f"Nome do cachorro: {cachorro.get_nome()}")
    print("O som do cachorro: ", end="")
    cachorro.som()

    print(f"Nome do gato: {gato.get_nome()}")
    print("O som do gato: ", end="")
    gato.som()
