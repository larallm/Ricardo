class Calculadora:
    def somar(self, a, b):
        return a + b

    def somar_três(self, a, b, c):
        return a + b + c


def main():
    calc = Calculadora()

    while True:
        print("\nEscolha a operação:")
        print("1: Somar dois números")
        print("2: Somar três números")
        print("3: Sair")

        opcao = input("Digite a opção: ")

        if opcao == '1':
            num1 = float(input("Digite o primeiro número: "))
            num2 = float(input("Digite o segundo número: "))

            resultado_soma = calc.somar(num1, num2)
            print("Resultado da soma:", resultado_soma)

        elif opcao == '2':
            num3 = float(input("Digite o primeiro número: "))
            num4 = float(input("Digite o segundo número: "))
            num5 = float(input("Digite o terceiro número: "))

            resultado_soma3 = calc.somar_três(num3, num4, num5)
            print("Resultado da soma:", resultado_soma3)

        elif opcao == '3':
            print("Encerrando o programa.")
            break

        else:
            print("Escolha inválida.")


if __name__ == "__main__":
    main()
