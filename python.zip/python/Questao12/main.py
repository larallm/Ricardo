class Produto:
    def __init__(self, nome, preco):
        self.nome = nome
        self.preco = preco

    def somar(self, outro):
        novo_nome = f"{self.nome} + {outro.nome}"
        novo_preco = self.preco + outro.preco
        return Produto(novo_nome, novo_preco)

    def __str__(self):
        return f"{self.nome}: R$ {self.preco:.2f}"


def main():
    nome1 = input("Digite o nome do primeiro produto: ")
    preco1 = float(input("Digite o preço do primeiro produto: "))

    nome2 = input("Digite o nome do segundo produto: ")
    preco2 = float(input("Digite o preço do segundo produto: "))

    produto1 = Produto(nome1, preco1)
    produto2 = Produto(nome2, preco2)
    produto3 = produto1.somar(produto2)

    print(produto3)


if __name__ == "__main__":
    main()
