class Carro:
    def __init__(self, marca, modelo, ano):
        self.marca = marca
        self.modelo = modelo
        self.ano = ano
        self.velocidade = 0

    def get_velocidade(self):
        return self.velocidade

    def acelerar(self, aumentar_velocidade):
        if aumentar_velocidade > 0:
            self.velocidade += aumentar_velocidade

    def frear(self, diminuir_velocidade):
        if diminuir_velocidade > 0:
            self.velocidade -= diminuir_velocidade
            if self.velocidade < 0:
                self.velocidade = 0

    def exibir_detalhes(self):
        print(f"Marca: {self.marca}, Modelo: {self.modelo}, Ano: {self.ano}")

    def exibir_velocidade(self):
        print(f"{self.modelo} está a {self.velocidade} km/h.")

if __name__ == "__main__":
    carro1 = Carro("Chevrolet", "Onix", 2022)
    carro2 = Carro("Volkswagen", "Golf", 2020)
    carro3 = Carro("Tesla", "Model S", 2023)

    carro1.exibir_detalhes()
    carro1.acelerar(50)
    carro1.exibir_velocidade()
    carro1.frear(30)
    carro1.exibir_velocidade()

    carro2.exibir_detalhes()
    carro2.acelerar(100)
    carro2.exibir_velocidade()
    carro2.frear(120)
    carro2.exibir_velocidade()

    carro3.exibir_detalhes()
    carro3.acelerar(80)
    carro3.exibir_velocidade()
