class SaldoInsuficiente(Exception):
    def __init__(self, saldo, valor_saque):
        super().__init__(f"Saldo insuficiente: R$ {saldo:.2f} para saque de R$ {valor_saque:.2f}")

class ContaBancaria:
    def __init__(self, saldo_inicial):
        self.saldo = saldo_inicial

    def sacar(self, valor):
        if valor > self.saldo:
            raise SaldoInsuficiente(self.saldo, valor)
        self.saldo -= valor
        return self.saldo


def main():
    saldo_inicial = float(input("Digite o saldo da conta: R$ "))
    conta = ContaBancaria(saldo_inicial)

    valor_saque = float(input("Digite o valor que deseja sacar: R$ "))

    try:
        conta.sacar(valor_saque)
        print(f"Saque realizado com sucesso! Novo saldo: R$ {conta.saldo:.2f}")
    except SaldoInsuficiente as e:
        print(e)


if __name__ == "__main__":
    main()
