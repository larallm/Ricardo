class Configuracao:
    _instancia = None

    def __new__(cls):
        if cls._instancia is None:
            cls._instancia = super(Configuracao, cls).__new__(cls)
            cls._instancia.configuracao = "Configuração padrão"
        return cls._instancia

    def get_configuracao(self):
        return self.configuracao

    def set_configuracao(self, configuracao):
        self.configuracao = configuracao


def main():
    config1 = Configuracao()
    print(config1.get_configuracao())

    config1.set_configuracao("Nova configuração")
    config2 = Configuracao()
    print(config2.get_configuracao())

    print("As instâncias são iguais?", config1 is config2)


if __name__ == "__main__":
    main()
