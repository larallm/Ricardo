class Motor:
    def __init__(self, tipo):
        self.tipo = tipo

    def get_tipo(self):
        return self.tipo

class Carro:
    def __init__(self, marca, modelo, ano, motor):
        self.marca = marca
        self.modelo = modelo
        self.ano = ano
        self.motor = motor

    def exibir_detalhes(self):
        print(f"Marca: {self.marca}, Modelo: {self.modelo}, Ano: {self.ano}, Motor: {self.motor.get_tipo()}")

if __name__ == "__main__":
    motor1 = Motor("1.0 Turbo")
    carro1 = Carro("Chevrolet", "Onix", 2022, motor1)

    motor2 = Motor("2.0 TSI")
    carro2 = Carro("Volkswagen", "Golf", 2020, motor2)

    motor3 = Motor("Elétrico")
    carro3 = Carro("Tesla", "Model S", 2023, motor3)

    carro1.exibir_detalhes()
    carro2.exibir_detalhes()
    carro3.exibir_detalhes()
