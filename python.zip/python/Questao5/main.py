from abc import ABC, abstractmethod

class Animal(ABC):
    def __init__(self, nome):
        self.nome = nome

    def get_nome(self):
        return self.nome

    @abstractmethod
    def som(self):
        pass

    @abstractmethod
    def comportamento(self):
        pass

class Gato(Animal):
    def __init__(self, nome):
        super().__init__(nome)

    def som(self):
        print("Miau!")

    def comportamento(self):
        print("O gato ronrona")

class Cachorro(Animal):
    def __init__(self, nome):
        super().__init__(nome)

    def som(self):
        print("Au")

    def comportamento(self):
        print("O cachorro balança o rabo")

if __name__ == "__main__":
    animais = []
    cachorro = Cachorro("Pituca")
    gato = Gato("Charlotte")

    print(f"Nome do cachorro: {cachorro.get_nome()}")
    print("O som do cachorro: ", end="")
    cachorro.som()
    print("Comportamento do cachorro: ", end="")
    cachorro.comportamento()

    print(f"Nome do gato: {gato.get_nome()}")
    print("O som do gato: ", end="")
    gato.som()
    print("Comportamento do gato: ", end="")
    gato.comportamento()
