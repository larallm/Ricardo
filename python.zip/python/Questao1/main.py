class Carro:
    def __init__(self, marca, modelo, ano):
        self.marca = marca
        self.modelo = modelo
        self.ano = ano

    def exibir_detalhes(self):
        print(f"Marca: {self.marca}, Modelo: {self.modelo}, Ano: {self.ano}")

if __name__ == "__main__":
    carro1 = Carro("Chevrolet", "Onix", 2022)
    carro2 = Carro("Volkswagen", "Golf", 2020)
    carro3 = Carro("Tesla", "Model S", 2023)

    carro1.exibir_detalhes()
    carro2.exibir_detalhes()
    carro3.exibir_detalhes()
