from abc import ABC, abstractmethod


class Imprimivel(ABC):
    @abstractmethod
    def imprimir(self):
        pass


class Empregado(Imprimivel):
    def __init__(self, nome, cargo, salario):
        self.nome = nome
        self.cargo = cargo
        self.salario = salario

    def get_nome(self):
        return self.nome

    def set_nome(self, nome):
        self.nome = nome

    def get_cargo(self):
        return self.cargo

    def set_cargo(self, cargo):
        self.cargo = cargo

    def get_salario(self):
        return self.salario

    def set_salario(self, salario):
        self.salario = salario

    def imprimir(self):
        print(self)

    def __str__(self):
        return f"Nome: {self.nome}, Cargo: {self.cargo}, Salário: {self.salario}"


class Empresa(Imprimivel):
    def __init__(self, nome):
        self.nome = nome
        self.empregados = []

    def get_nome(self):
        return self.nome

    def set_nome(self, nome):
        self.nome = nome

    def adicionar_empregado(self, empregado):
        self.empregados.append(empregado)

    def get_empregados(self):
        return self.empregados

    def imprimir(self):
        print(self)

    def __str__(self):
        sb = f"Empresa: {self.nome}\nEmpregados:\n"
        for empregado in self.empregados:
            sb += str(empregado) + "\n"
        return sb


def main():
    empresa = Empresa("Google")

    emp1 = Empregado("Lara", "Desenvolvedora", 50000)
    emp2 = Empregado("Bob", "Gerente", 15000)

    empresa.adicionar_empregado(emp1)
    empresa.adicionar_empregado(emp2)

    empresa.imprimir()


if __name__ == "__main__":
    main()
