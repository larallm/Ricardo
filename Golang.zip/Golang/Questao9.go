package main

import (
	"fmt"
)

// Define a estrutura Empregado
type Empregado struct {
	nome    string
	cargo   string
	salario float64
}

// Método para imprimir informações do empregado
func (e Empregado) imprimir() {
	fmt.Println(e)
}

// Método toString para formatar a saída
func (e Empregado) String() string {
	return fmt.Sprintf("Nome: %s, Cargo: %s, Salário: %.2f", e.nome, e.cargo, e.salario)
}

// Define a estrutura Empresa
type Empresa struct {
	nome      string
	empregados []Empregado
}

// Método para adicionar um empregado
func (e *Empresa) adicionarEmpregado(emp Empregado) {
	e.empregados = append(e.empregados, emp)
}

// Método para imprimir informações da empresa e seus empregados
func (e Empresa) imprimir() {
	fmt.Println(e)
}

// Método toString para formatar a saída
func (e Empresa) String() string {
	resultado := fmt.Sprintf("Empresa: %s\nEmpregados:\n", e.nome)
	for _, emp := range e.empregados {
		resultado += emp.String() + "\n"
	}
	return resultado
}

// Função principal
func main() {
	empresa := Empresa{nome: "Google"}

	emp1 := Empregado{nome: "Lara", cargo: "Desenvolvedora", salario: 50000}
	emp2 := Empregado{nome: "Lucas", cargo: "Gerente", salario: 15000}

	empresa.adicionarEmpregado(emp1)
	empresa.adicionarEmpregado(emp2)

	empresa.imprimir()
}
