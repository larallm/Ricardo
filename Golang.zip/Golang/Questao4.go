package main

import "fmt"

// Interface Animal define o método som
type Animal interface {
	Som()
	GetNome() string
}

// Estrutura Gato que implementa Animal
type Gato struct {
	Nome string
}

func (g Gato) Som() {
	fmt.Println("Miau!")
}

func (g Gato) GetNome() string {
	return g.Nome
}

// Estrutura Cachorro que implementa Animal
type Cachorro struct {
	Nome string
}

func (c Cachorro) Som() {
	fmt.Println("Au")
}

func (c Cachorro) GetNome() string {
	return c.Nome
}

func main() {
	cachorro := Cachorro{"Pituca"}
	gato := Gato{"Charlotte"}

	fmt.Println("Nome do cachorro:", cachorro.GetNome())
	fmt.Print("O som do cachorro: ")
	cachorro.Som()

	fmt.Println("Nome do gato:", gato.GetNome())
	fmt.Print("O som do gato: ")
	gato.Som()
}
