package main

import "fmt"

type Motor struct {
	Tipo string
}

func (m Motor) GetTipo() string {
	return m.Tipo
}

type Carro struct {
	Marca  string
	Modelo string
	Ano    int
	Motor  Motor
}

func (c Carro) ExibirDetalhes() {
	fmt.Printf("Marca: %s, Modelo: %s, Ano: %d, Motor: %s\n", c.Marca, c.Modelo, c.Ano, c.Motor.GetTipo())
}

func main() {
	motor1 := Motor{Tipo: "1.0 Turbo"}
	carro1 := Carro{Marca: "Chevrolet", Modelo: "Onix", Ano: 2022, Motor: motor1}

	motor2 := Motor{Tipo: "2.0 TSI"}
	carro2 := Carro{Marca: "Volkswagen", Modelo: "Golf", Ano: 2020, Motor: motor2}

	motor3 := Motor{Tipo: "Elétrico"}
	carro3 := Carro{Marca: "Tesla", Modelo: "Model S", Ano: 2023, Motor: motor3}

	carro1.ExibirDetalhes()
	carro2.ExibirDetalhes()
	carro3.ExibirDetalhes()
}
