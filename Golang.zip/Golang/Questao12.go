package main

import (
    "fmt"
)

// Produto representa um produto com nome e preço
type Produto struct {
    nome  string
    preco float64
}

// Somar soma o preço de dois produtos e retorna um novo produto
func (p Produto) Somar(outro Produto) Produto {
    return Produto{
        nome:  p.nome + " + " + outro.nome,
        preco: p.preco + outro.preco,
    }
}

// String retorna a representação em string do produto
func (p Produto) String() string {
    return fmt.Sprintf("%s: R$ %.2f", p.nome, p.preco)
}

func main() {
    var nome1, nome2 string
    var preco1, preco2 float64

    fmt.Print("Digite o nome do primeiro produto: ")
    fmt.Scanln(&nome1)
    fmt.Print("Digite o preço do primeiro produto: ")
    fmt.Scan(&preco1)

    fmt.Print("Digite o nome do segundo produto: ")
    fmt.Scanln() // Limpa o buffer
    fmt.Scanln(&nome2)
    fmt.Print("Digite o preço do segundo produto: ")
    fmt.Scan(&preco2)

    produto1 := Produto{nome: nome1, preco: preco1}
    produto2 := Produto{nome: nome2, preco: preco2}
    produto3 := produto1.Somar(produto2)

    fmt.Println(produto3)
}
