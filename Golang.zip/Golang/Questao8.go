package main

import (
	"fmt"
)

type Empregado struct {
	nome    string
	cargo   string
	salario float64
}

func (e *Empregado) String() string {
	return fmt.Sprintf("Nome: %s, Cargo: %s, Salário: %.2f", e.nome, e.cargo, e.salario)
}

type Empresa struct {
	nome      string
	empregados []Empregado
}

func (e *Empresa) adicionarEmpregado(emp Empregado) {
	e.empregados = append(e.empregados, emp)
}

func (e *Empresa) String() string {
	resultado := fmt.Sprintf("Empresa: %s\nEmpregados:\n", e.nome)
	for _, emp := range e.empregados {
		resultado += emp.String() + "\n"
	}
	return resultado
}

func main() {
	empresa := Empresa{nome: "Google"}

	emp1 := Empregado{nome: "Lara", cargo: "Desenvolvedora", salario: 50000}
	emp2 := Empregado{nome: "Bob", cargo: "Gerente", salario: 15000}

	empresa.adicionarEmpregado(emp1)
	empresa.adicionarEmpregado(emp2)

	fmt.Println(empresa)
}
