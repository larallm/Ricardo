package main

import (
    "fmt"
)

// Funcionario é uma interface que define o método calcularSalario
type Funcionario interface {
    CalcularSalario() float64
    GetNome() string
}

// FuncionarioAssalariado representa um funcionário assalariado
type FuncionarioAssalariado struct {
    nome          string
    salarioMensal float64
}

// FuncionarioHorista representa um funcionário horista
type FuncionarioHorista struct {
    nome            string
    valorHora       float64
    horasTrabalhadas int
}

// CalcularSalario para FuncionarioAssalariado
func (f FuncionarioAssalariado) CalcularSalario() float64 {
    return f.salarioMensal
}

// GetNome para FuncionarioAssalariado
func (f FuncionarioAssalariado) GetNome() string {
    return f.nome
}

// CalcularSalario para FuncionarioHorista
func (f FuncionarioHorista) CalcularSalario() float64 {
    return f.valorHora * float64(f.horasTrabalhadas)
}

// GetNome para FuncionarioHorista
func (f FuncionarioHorista) GetNome() string {
    return f.nome
}

func main() {
    funcionario1 := FuncionarioHorista{"Pedro", 201.0, 160}
    funcionario2 := FuncionarioAssalariado{"Lara", 50000.0}

    // Exibe o salário de cada funcionário
    fmt.Printf("Salário de %s: R$ %.2f\n", funcionario1.GetNome(), funcionario1.CalcularSalario())
    fmt.Printf("Salário de %s: R$ %.2f\n", funcionario2.GetNome(), funcionario2.CalcularSalario())
}
