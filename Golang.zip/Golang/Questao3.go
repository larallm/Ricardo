package main

import "fmt"

type ContaBancaria struct {
	Titular string
	Saldo   float64
}

func (c *ContaBancaria) Depositar(valor float64) {
	if valor > 0 {
		c.Saldo += valor
	}
}

func (c *ContaBancaria) Sacar(valor float64) bool {
	if valor > 0 && c.Saldo >= valor {
		c.Saldo -= valor
		return true
	}
	return false
}

func main() {
	conta := ContaBancaria{"Lara Lopes Marques", 1200}

	conta.Depositar(700.0)
	fmt.Println("Titular:", conta.Titular)
	fmt.Println("Saldo após depósito:", conta.Saldo)

	if conta.Sacar(200) {
		fmt.Println("Saque realizado com sucesso.")
	} else {
		fmt.Println("Saldo insuficiente.")
	}
	fmt.Println("Saldo após saque:", conta.Saldo)
}
