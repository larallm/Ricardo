package main

import (
	"fmt"
)

// SaldoInsuficiente é um tipo de erro que representa saldo insuficiente para um saque
type SaldoInsuficiente struct {
	Saldo      float64
	ValorSaque float64
}

// Error implementa a interface de erro para SaldoInsuficiente
func (e *SaldoInsuficiente) Error() string {
	return fmt.Sprintf("Saldo insuficiente: R$ %.2f para saque de R$ %.2f", e.Saldo, e.ValorSaque)
}

// ContaBancaria representa uma conta bancária
type ContaBancaria struct {
	Saldo float64
}

// NovaContaBancaria cria uma nova conta com um saldo inicial
func NovaContaBancaria(saldoInicial float64) *ContaBancaria {
	return &ContaBancaria{Saldo: saldoInicial}
}

// Sacar tenta sacar um valor da conta
func (c *ContaBancaria) Sacar(valor float64) error {
	if valor > c.Saldo {
		return &SaldoInsuficiente{Saldo: c.Saldo, ValorSaque: valor}
	}
	c.Saldo -= valor
	return nil
}

func main() {
	var saldoInicial, valorSaque float64

	fmt.Print("Digite o saldo da conta: R$ ")
	fmt.Scan(&saldoInicial)

	conta := NovaContaBancaria(saldoInicial)

	fmt.Print("Digite o valor que deseja sacar: R$ ")
	fmt.Scan(&valorSaque)

	err := conta.Sacar(valorSaque)
	if err != nil {
		fmt.Println(err)
	} else {
		fmt.Printf("Saque realizado com sucesso! Novo saldo: R$ %.2f\n", conta.Saldo)
	}
}
