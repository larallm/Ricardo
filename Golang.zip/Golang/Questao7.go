package main

import (
	"fmt"
	"log"
	"os"
)

type Professor struct {
	nome     string
	telefone string
	escolas  []Escola
}

func (p *Professor) adicionarEscola(e Escola) {
	p.escolas = append(p.escolas, e)
}

type Escola struct {
	nome      string
	professores []Professor
}

func (e *Escola) adicionarProfessor(p Professor) {
	e.professores = append(e.professores, p)
}

func main() {
	var escola Escola
	var professor *Professor

	for {
		fmt.Println("\nMenu:")
		fmt.Println("1. Contratar Professor")
		fmt.Println("2. Cadastro Professor")
		fmt.Println("3. Cadastro Escola")
		fmt.Println("4. Informações Professor")
		fmt.Println("5. Sair")
		fmt.Print("Escolha uma opção: ")

		var opcao int
		_, err := fmt.Scan(&opcao)
		if err != nil {
			log.Println("Entrada inválida. Por favor, insira um número.")
			continue
		}

		switch opcao {
		case 1:
			contratarProfessor(&escola, professor)
		case 2:
			professor = cadastrarProfessor()
			if escola.nome != "" {
				escola.adicionarProfessor(*professor)
				professor.adicionarEscola(escola)
			}
		case 3:
			escola = cadastrarEscola()
		case 4:
			exibirInformacoesProfessor(professor)
		case 5:
			fmt.Println("Encerrando o programa.")
			os.Exit(0)
		default:
			fmt.Println("Opção inválida.")
		}
	}
}

func contratarProfessor(escola *Escola, professor *Professor) {
	if escola.nome == "" {
		fmt.Println("Não é possível contratar um professor. Escola não cadastrada.")
		return
	}

	fmt.Print("Digite o nome do professor a ser contratado: ")
	var nome string
	fmt.Scan(&nome)
	novoProfessor := Professor{nome: nome}

	escola.adicionarProfessor(novoProfessor)
	novoProfessor.adicionarEscola(escola)
	fmt.Println("Professor", nome, "contratado com sucesso!")
}

func cadastrarEscola() Escola {
	var escola Escola

	fmt.Print("Digite o nome da escola: ")
	fmt.Scan(&escola.nome)

	return escola
}

func cadastrarProfessor() *Professor {
	var professor Professor

	fmt.Print("Digite o nome do professor: ")
	fmt.Scan(&professor.nome)

	return &professor
}

func exibirInformacoesProfessor(professor *Professor) {
	if professor == nil {
		fmt.Println("Nenhum professor cadastrado.")
		return
	}
	fmt.Println("Informações do Professor:")
	fmt.Println("Nome do Professor:", professor.nome)
	fmt.Println("Telefone do Professor:", professor.telefone)
	fmt.Println("Escolas associadas ao Professor:")

	if len(professor.escolas) == 0 {
		fmt.Println("Nenhuma escola associada.")
	} else {
		for _, escola := range professor.escolas {
			fmt.Println(" -", escola.nome)
		}
	}
}
