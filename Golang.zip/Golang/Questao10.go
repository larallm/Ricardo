package main

import (
    "fmt"
)

type Calculadora struct{}

func (c *Calculadora) Somar(a, b float64) float64 {
    return a + b
}

func (c *Calculadora) SomarTres(a, b, c float64) float64 {
    return a + b + c
}

func main() {
    var calc Calculadora
    var opcao int

    for {
        fmt.Println("\nEscolha a operação:")
        fmt.Println("1: Somar dois números")
        fmt.Println("2: Somar três números")
        fmt.Println("3: Sair")
        fmt.Print("Opção: ")
        fmt.Scan(&opcao)

        switch opcao {
        case 1:
            var num1, num2 float64
            fmt.Print("Digite o primeiro número: ")
            fmt.Scan(&num1)
            fmt.Print("Digite o segundo número: ")
            fmt.Scan(&num2)

            resultadoSoma := calc.Somar(num1, num2)
            fmt.Printf("Resultado da soma: %.2f\n", resultadoSoma)

        case 2:
            var num1, num2, num3 float64
            fmt.Print("Digite o primeiro número: ")
            fmt.Scan(&num1)
            fmt.Print("Digite o segundo número: ")
            fmt.Scan(&num2)
            fmt.Print("Digite o terceiro número: ")
            fmt.Scan(&num3)

            resultadoSoma := calc.SomarTres(num1, num2, num3)
            fmt.Printf("Resultado da soma: %.2f\n", resultadoSoma)

        case 3:
            fmt.Println("Encerrando o programa.")
            return

        default:
            fmt.Println("Escolha inválida. Tente novamente.")
        }
    }
}
