package main

import "fmt"

type Animal interface {
	Som()
	Comportamento()
	GetNome() string
}

type Gato struct {
	Nome string
}

func (g Gato) Som() {
	fmt.Println("Miau!")
}

func (g Gato) Comportamento() {
	fmt.Println("O gato ronrona")
}

func (g Gato) GetNome() string {
	return g.Nome
}

type Cachorro struct {
	Nome string
}

func (c Cachorro) Som() {
	fmt.Println("Au")
}

func (c Cachorro) Comportamento() {
	fmt.Println("O cachorro balança o rabo")
}

func (c Cachorro) GetNome() string {
	return c.Nome
}

func main() {
	animais := []Animal{}

	cachorro := Cachorro{"Pituca"}
	gato := Gato{"Charlotte"}

	animais = append(animais, cachorro, gato)

	for _, animal := range animais {
		fmt.Println("Nome do animal:", animal.GetNome())
		fmt.Print("Som do animal: ")
		animal.Som()
		fmt.Print("Comportamento do animal: ")
		animal.Comportamento()
		fmt.Println()
	}
}
