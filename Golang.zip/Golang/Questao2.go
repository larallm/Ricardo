package main

import "fmt"

type Carro struct {
	Marca     string
	Modelo    string
	Ano       int
	Velocidade int
}

func (c *Carro) Acelerar(aumentarVelocidade int) {
	if aumentarVelocidade > 0 {
		c.Velocidade += aumentarVelocidade
	}
}

func (c *Carro) Frear(diminuirVelocidade int) {
	if diminuirVelocidade > 0 {
		c.Velocidade -= diminuirVelocidade
		if c.Velocidade < 0 {
			c.Velocidade = 0
		}
	}
}

func (c Carro) ExibirDetalhes() {
	fmt.Printf("Marca: %s, Modelo: %s, Ano: %d\n", c.Marca, c.Modelo, c.Ano)
}

func (c Carro) ExibirVelocidade() {
	fmt.Printf("%s está a %d km/h.\n", c.Modelo, c.Velocidade)
}

func main() {
	carro1 := Carro{"Chevrolet", "Onix", 2022, 0}
	carro2 := Carro{"Volkswagen", "Golf", 2020, 0}
	carro3 := Carro{"Tesla", "Model S", 2023, 0}

	carro1.ExibirDetalhes()
	carro1.Acelerar(50)
	carro1.ExibirVelocidade()
	carro1.Frear(30)
	carro1.ExibirVelocidade()

	carro2.ExibirDetalhes()
	carro2.Acelerar(100)
	carro2.ExibirVelocidade()
	carro2.Frear(120)
	carro2.ExibirVelocidade()

	carro3.ExibirDetalhes()
	carro3.Acelerar(80)
	carro3.ExibirVelocidade()
}
