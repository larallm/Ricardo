package main

import (
    "fmt"
    "sync"
)

// Configuracao representa a configuração singleton
type Configuracao struct {
    configuracao string
}

var (
    instancia *Configuracao
    once      sync.Once
)

// GetInstancia retorna a instância única da Configuracao
func GetInstancia() *Configuracao {
    once.Do(func() {
        instancia = &Configuracao{
            configuracao: "Configuração padrão",
        }
    })
    return instancia
}

// GetConfiguracao retorna a configuração atual
func (c *Configuracao) GetConfiguracao() string {
    return c.configuracao
}

// SetConfiguracao define uma nova configuração
func (c *Configuracao) SetConfiguracao(configuracao string) {
    c.configuracao = configuracao
}

func main() {
    config1 := GetInstancia()
    fmt.Println(config1.GetConfiguracao())

    config1.SetConfiguracao("Nova configuração")
    config2 := GetInstancia()
    fmt.Println(config2.GetConfiguracao())

    fmt.Println("As instâncias são iguais?", config1 == config2)
}
