public class Main {
    public static void main(String[] args) {
        Empresa empresa = new Empresa("Google");

        Empregado emp1 = new Empregado("Lara", "Desenvolvedora", 50000);
        Empregado emp2 = new Empregado("Bob", "Gerente", 15000);

        empresa.adicionarEmpregado(emp1);
        empresa.adicionarEmpregado(emp2);

        System.out.println(empresa);
    }
}