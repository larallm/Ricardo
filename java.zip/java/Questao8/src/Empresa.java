import java.util.ArrayList;
import java.util.List;

public class Empresa {
    private String nome;
    private List<Empregado> empregados;

    public Empresa(String nome) {
        this.nome = nome;
        this.empregados = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void adicionarEmpregado(Empregado empregado) {
        empregados.add(empregado);
    }

    public List<Empregado> getEmpregados() {
        return empregados;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Empresa: " + nome + "\nEmpregados:\n");
        for (Empregado empregado : empregados) {
            sb.append(empregado.toString()).append("\n");
        }
        return sb.toString();
    }
}
