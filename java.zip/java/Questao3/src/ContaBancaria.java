public class ContaBancaria {
    private double saldo;
    private String titular;

    public ContaBancaria(String titular, double saldoInicial) {
        this.titular = titular;
        this.depositar(saldoInicial);
    }

    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
        }
    }

    public boolean sacar(double valor) {
        if (valor > 0 && saldo >= valor) {
            saldo -= valor;
            return true;
        } else {
            return false;
        }
    }

    public double getSaldo() {
        return saldo;
    }

    public String getTitular() {
        return titular;
    }

    public static void main(String[] args) {
        ContaBancaria conta = new ContaBancaria("Lara Lopes Marques", 1200);

        conta.depositar(700.0);
        System.out.println("Titular: " + conta.getTitular());
        System.out.println("Saldo após depósito: " + conta.getSaldo());

        conta.sacar(200);
        System.out.println("Titular: " + conta.getTitular());
        System.out.println("Saldo após saque: " + conta.getSaldo());
    }
}
