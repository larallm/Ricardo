import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Calculadora calc = new Calculadora();

        while (true) {
            System.out.println("\nEscolha a operação:");
            System.out.println("1: Somar dois números");
            System.out.println("2: Somar três números");
            System.out.println("3: Sair");

            int opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1:
                    System.out.print("Digite o primeiro número: ");
                    double num1 = scanner.nextDouble();

                    System.out.print("Digite o segundo número: ");
                    double num2 = scanner.nextDouble();

                    double resultadoSoma = calc.somar(num1, num2);
                    System.out.println("Resultado da soma: " + resultadoSoma);
                    break;

                case 2:
                    System.out.print("Digite o primeiro número: ");
                    double num3 = scanner.nextDouble();

                    System.out.print("Digite o segundo número: ");
                    double num4 = scanner.nextDouble();

                    System.out.print("Digite o terceiro número: ");
                    double num5 = scanner.nextDouble();

                    double resultadoSoma3 = calc.somar(num3, num4, num5);
                    System.out.println("Resultado da soma: " + resultadoSoma3);
                    break;

                case 3:
                    System.out.println("Encerrando o programa.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Escolha inválida.");
                    break;
            }
            scanner.nextLine();
        }
    }
}