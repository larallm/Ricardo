public class Animal {
    protected String nome;

    public Animal(String nome) {
        this.nome = nome;
    }
    public String getNome() {
        return nome;
    }

    public void som() {
        System.out.println("O animal faz esse som");
    }

}
