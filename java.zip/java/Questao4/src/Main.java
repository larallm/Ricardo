public class Main {
    public static void main(String[] args) {
        Cachorro cachorro = new Cachorro("Pituca");
        Gato gato = new Gato("Charlotte");

        System.out.println("Nome do cachorro: " + cachorro.getNome());
        System.out.print("O som do cachorro: ");
        cachorro.som();

        System.out.println("Nome do gato: " + gato.getNome());
        System.out.print("O som do gato: ");
        gato.som();
    }
}
