public class Main {
    public static void main(String[] args) {
        Funcionario funcionario1 = new FuncionarioHorista("Pedro", 201.0, 160);
        Funcionario funcionario2 = new FuncionarioAssalariado("Lara", 50000.0);

        System.out.println("Salário de " + funcionario1.nome + ": R$ " + funcionario1.calcularSalario());
        System.out.println("Salário de " + funcionario2.nome + ": R$ " + funcionario2.calcularSalario());

    }
}