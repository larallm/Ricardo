public class Carro {
    private String marca;
    private String modelo;
    private int ano;
    private int velocidade;

    public Carro(String marca, String modelo, int ano) {
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.velocidade = 0;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public void acelerar(int aumentarVelocidade) {
        if (aumentarVelocidade > 0) {
            velocidade += aumentarVelocidade;
        }
    }

    public void frear(int diminuirVelocidade) {
        if (diminuirVelocidade > 0) {
            velocidade -= diminuirVelocidade;
            if (velocidade < 0) {
                velocidade = 0;
            }
        }
    }

    public void exibirDetalhes() {
        System.out.println("Marca: " + marca + ", Modelo: " + modelo + ", Ano: " + ano);
    }

    public void exibirVelocidade() {
        System.out.println(modelo + " está a " + velocidade + " km/h.");
    }

    public static void main(String[] args) {
        Carro carro1 = new Carro("Chevrolet", "Onix", 2022);
        Carro carro2 = new Carro("Volkswagen", "Golf", 2020);
        Carro carro3 = new Carro("Tesla", "Model S", 2023);

        carro1.exibirDetalhes();
        carro1.acelerar(50);
        carro1.exibirVelocidade();
        carro1.frear(30);
        carro1.exibirVelocidade();

        carro2.exibirDetalhes();
        carro2.acelerar(100);
        carro2.exibirVelocidade();
        carro2.frear(120);
        carro2.exibirVelocidade();

        carro3.exibirDetalhes();
        carro3.acelerar(80);
        carro3.exibirVelocidade();
    }
}
