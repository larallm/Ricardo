import java.util.ArrayList;
import java.util.List;

public class Professor {
    private String nomeProfessor;
    private String telefone;
    private List<Escola> escolas;

    public Professor() {
        this.escolas = new ArrayList<>();
    }

    public String getNomeProfessor() {
        return nomeProfessor;
    }

    public void setNomeProfessor(String nomeProfessor) {
        this.nomeProfessor = nomeProfessor;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void adicionarEscola(Escola escola) {
        this.escolas.add(escola);
    }

    public List<Escola> getEscolas() {
        return escolas;
    }
}
