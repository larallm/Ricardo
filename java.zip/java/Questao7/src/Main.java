import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Escola escola = null;
        Professor professor = null;

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Contratar Professor");
            System.out.println("2. Cadastro Professor");
            System.out.println("3. Cadastro Escola");
            System.out.println("4. Informações Professor");
            System.out.println("5. Sair");
            System.out.println("Escolha uma opção:");

            int opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1:
                    contratarProfessor(escola, scanner);
                    break;
                case 2:
                    professor = cadastrarProfessor(scanner);
                    if (escola != null) {
                        escola.adicionarProfessor(professor);
                        professor.adicionarEscola(escola);
                    }
                    break;
                case 3:
                    escola = cadastrarEscola(scanner);
                    break;
                case 4:
                    exibirInformacoesProfessor(professor);
                    break;
                case 5:
                    System.out.println("Encerrando o programa.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Opção inválida.");
                    break;
            }
        }
    }

    private static void contratarProfessor(Escola escola, Scanner scanner) {
        if (escola == null) {
            System.out.println("Não é possível contratar um professor. Escola não cadastrada.");
            return;
        }

        System.out.println("Digite o nome do professor a ser contratado:");
        String nomeProfessor = scanner.nextLine();
        Professor novoProfessor = new Professor();
        novoProfessor.setNomeProfessor(nomeProfessor);

        escola.adicionarProfessor(novoProfessor);
        novoProfessor.adicionarEscola(escola);
        System.out.println("Professor " + nomeProfessor + " contratado com sucesso!");
    }

    private static Escola cadastrarEscola(Scanner scanner) {
        Escola escola = new Escola();

        System.out.println("Digite o nome da escola:");
        escola.setNome(scanner.nextLine());

        return escola;
    }

    private static Professor cadastrarProfessor(Scanner scanner) {
        Professor professor = new Professor();

        System.out.println("Digite o nome do professor:");
        professor.setNomeProfessor(scanner.nextLine());

        return professor;
    }

    private static void exibirInformacoesProfessor(Professor professor) {
        if (professor == null) {
            System.out.println("Nenhum professor cadastrado.");
        } else {
            System.out.println("Informações do Professor:");
            System.out.println("Nome do Professor: " + professor.getNomeProfessor());
            System.out.println("Telefone do Professor: " + professor.getTelefone());
            System.out.println("Escolas associadas ao Professor:");

            List<Escola> escolas = professor.getEscolas();
            if (escolas.isEmpty()) {
                System.out.println("Nenhuma escola associada.");
            } else {
                for (Escola escola : escolas) {
                    System.out.println(" - " + escola.getNome());
                }
            }
        }
    }
}
