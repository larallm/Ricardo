package print;

public interface Imprimivel {
    void imprimir();
}
