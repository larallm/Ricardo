import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
            System.out.print("Digite o nome do primeiro produto: ");
            String nome1 = scanner.nextLine();
            System.out.print("Digite o preço do primeiro produto: ");
            double preco1 = scanner.nextDouble();
            scanner.nextLine();
            System.out.print("Digite o nome do segundo produto: ");
            String nome2 = scanner.nextLine();
            System.out.print("Digite o preço do segundo produto: ");
            double preco2 = scanner.nextDouble();

            Produto produto1 = new Produto(nome1, preco1);
            Produto produto2 = new Produto(nome2, preco2);
            Produto produto3 = produto1.somar(produto2);

            System.out.println(produto3);

            scanner.close();
        }
    }