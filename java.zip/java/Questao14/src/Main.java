public class Main {
    public static void main(String[] args) {

        Configuracao config1 = Configuracao.getInstancia();
        System.out.println(config1.getConfiguracao());

        config1.setConfiguracao("Nova configuração");
        Configuracao config2 = Configuracao.getInstancia();
        System.out.println(config2.getConfiguracao());

        System.out.println("As instâncias são iguais? " + (config1 == config2));

    }
}