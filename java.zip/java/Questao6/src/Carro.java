class Carro {
    private String marca;
    private String modelo;
    private int ano;
    private Motor motor; // Atributo do tipo Motor

    public Carro(String marca, String modelo, int ano, Motor motor) {
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.motor = motor; // Inicializa o motor
    }

    public void exibirDetalhes() {
        System.out.println("Marca: " + marca + ", Modelo: " + modelo + ", Ano: " + ano + ", Motor: " + motor.getTipo());
    }
}