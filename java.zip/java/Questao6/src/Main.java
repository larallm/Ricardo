
public class Main {
    public static void main(String[] args) {
        Motor motor1 = new Motor("1.0 Turbo");
        Carro carro1 = new Carro("Chevrolet", "Onix", 2022, motor1);

        Motor motor2 = new Motor("2.0 TSI");
        Carro carro2 = new Carro("Volkswagen", "Golf", 2020, motor2);

        Motor motor3 = new Motor("Elétrico");
        Carro carro3 = new Carro("Tesla", "Model S", 2023, motor3);

        carro1.exibirDetalhes();
        carro2.exibirDetalhes();
        carro3.exibirDetalhes();
    }
}