class Cachorro extends Animal {
    public Cachorro(String nome) {
        super(nome);
    }

    @Override
    public void som() {
        System.out.println("Au");
    }
    @Override
    public void comportamento() {
        System.out.println("O cachorro balança o rabo ");
    }
}
