import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o saldo da conta: R$ ");
        double saldoInicial = scanner.nextDouble();
        ContaBancaria conta = new ContaBancaria(saldoInicial);

        System.out.print("Digite o valor que deseja sacar: R$ ");
        double valorSaque = scanner.nextDouble();

        try {
            conta.sacar(valorSaque);
            System.out.println("Saque realizado com sucesso! Novo saldo: R$ " + String.format("%.2f", conta.saldo));
        } catch (SaldoInsuficiente e) {
            System.out.println(e.getMessage());
        } finally {
            scanner.close();
        }
    }
}