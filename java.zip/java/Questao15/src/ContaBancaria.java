public class ContaBancaria {
    double saldo;

    public ContaBancaria(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    public double sacar(double valor) throws SaldoInsuficiente {
        if (valor > saldo) {
            throw new SaldoInsuficiente(saldo, valor);
        }
        saldo -= valor;
        return saldo;
    }
}
