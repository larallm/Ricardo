class SaldoInsuficiente extends Exception {
    public SaldoInsuficiente(double saldo, double valorSaque) {
        super("Saldo insuficiente: R$ " + String.format("%.2f", saldo) + " para saque de R$ " + String.format("%.2f", valorSaque));
    }
}